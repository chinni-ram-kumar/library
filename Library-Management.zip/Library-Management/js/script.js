$(document).ready(function () {
    $(window).on('load', function () {
        $('body').css('animation', 'fadein 5s');
    });
});